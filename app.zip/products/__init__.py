# Import views and forms from their respective modules
# from .views import *
# from .forms import *

# This makes the views and forms available when importing from the products package